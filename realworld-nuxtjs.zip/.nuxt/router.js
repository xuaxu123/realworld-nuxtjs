import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _451d9ce0 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _76e4e676 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _6547577a = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _7e81bffa = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _2f361dee = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _5cbb505a = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _b0ed3960 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _451d9ce0,
    children: [{
      path: "",
      component: _76e4e676,
      name: "home"
    }, {
      path: "/login",
      component: _6547577a,
      name: "login"
    }, {
      path: "/register",
      component: _6547577a,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _7e81bffa,
      name: "profile"
    }, {
      path: "/settings",
      component: _2f361dee,
      name: "settings"
    }, {
      path: "/editor",
      component: _5cbb505a,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _b0ed3960,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
